module Main where

import Network.Socket
import System.IO
import Control.Concurrent
import Control.Concurrent.Chan
import Control.Monad.Fix
import Control.Monad (unless)

import Data.UnixTime
import Crypto.Hash.SHA256

data Appointment = Appointment { id :: Int
                               , date :: String
                               , time :: String
                               , location :: String
                               , description :: String
                               } deriving (Show)

type Msg = String

main :: IO ()
main = do
    sock <- socket AF_INET Stream 0             -- Create socket
    setSocketOption sock ReuseAddr 1            -- Make socket immediately reusable - eases debugging.
    bind sock (SockAddrInet 4000 0)             -- Listen on TCP port 4000
    listen sock 2                               -- Allow a maximum of 2 queued connections

    chan <- newChan                             -- Create a new message channel
    mainLoop sock chan

-- The server loop which listens for new connections
mainLoop :: Socket -> Chan Msg -> IO ()
mainLoop sock chan = do
    conn <- accept sock                        -- Accept a connection and handle it
    forkIO $ runConn conn                      -- Fork to a new thread to handle the connection
    mainLoop sock chan

-- Handle a single connection
runConn :: (Socket, SockAddr) -> IO ()
runConn (sock, _) = do
    hdl <- socketToHandle sock ReadWriteMode    -- Convert socket to a handle
    hSetBuffering hdl NoBuffering               -- Set buffering mode

    welcome hdl
    -- authenticate hdl
    runSession hdl -- Loops

    hClose hdl


runSession :: Handle -> IO ()
runSession hdl = do
    input <- hGetLine hdl

    unless (take 4 input == "quit") $ do
        -- Split input into args
        let args = words input

        -- Handle command
        let cmd = lookup (head args) dispatch
        case cmd of
            Just f -> f hdl args
            Nothing -> help hdl args

        -- Loop
        runSession hdl

authenticate :: Handle -> IO ()
authenticate hdl = do
    hPutStrLn hdl "Please enter your name: "
    name <- hGetLine hdl
    hPutStrLn hdl $ "Welcome, " ++ name ++ "!"

welcome :: Handle -> IO ()
welcome = flip hPutStrLn "\ESC[31mWelcome!\ESC[0m\n";

dispatch :: [(String, Handle -> [String] -> IO ())]
dispatch = [ ("help\r\n", help)
           , ("list\r\n", list)
           , ("search\r\n", search)
           , ("clear\r\n", clear)
           , ("add\r\n", add)
           , ("remove\r\n", remove)
           ]

help :: Handle -> [String] -> IO ()
help hdl _ = hPutStrLn hdl
  "\nAppointments Manager\n\
  \-----------------------\n\
  \\ESC[1;34m\
  \help         - show this message\n\
  \search <arg> - search appointments\n\
  \list         - list all appointments\n\
  \clear        - clear the screen\n\
  \add <args>   - add a new appointment\n\
  \remove <n>   - remove appoint with id n\n\
  \\ESC[0m"

search :: Handle -> [String] -> IO ()
search hdl _ = return ()

clear :: Handle -> [String] -> IO ()
clear hdl _ = hPutStrLn hdl "\ESC[2J"

list :: Handle -> [String] -> IO ()
list hdl _ = return ()

add :: Handle -> [String] -> IO ()
add hdl _ = return ()
-- add s [] = help s []
-- add s items = appendFile appointFile (unwords items ++ "\n")

remove :: Handle -> [String] -> IO ()
remove hdl _ = return ()